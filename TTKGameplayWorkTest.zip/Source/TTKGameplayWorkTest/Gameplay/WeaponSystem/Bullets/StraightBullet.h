﻿#pragma once

#include "CoreMinimal.h"
#include "TTKGameplayWorkTestBullet.h"
#include "StraightBullet.generated.h"

UCLASS()
class TTKGAMEPLAYWORKTEST_API AStraightBullet : public ATTKGameplayWorkTestBullet
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere)
	float Speed = 500.f;

protected:
	virtual void BeginPlay() override;

	virtual FVector GetNewLocation(float DeltaSeconds) override;
};
