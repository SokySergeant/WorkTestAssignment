﻿#include "StraightBullet.h"

void AStraightBullet::BeginPlay()
{
	Super::BeginPlay();
}

FVector AStraightBullet::GetNewLocation(float DeltaSeconds)
{
	return GetActorLocation() + GetActorForwardVector() * Speed * DeltaSeconds;
}
