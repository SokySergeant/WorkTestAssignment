﻿#pragma once

#include "CoreMinimal.h"
#include "TTKGameplayWorkTestBullet.h"
#include "ArcingBullet.generated.h"

UCLASS()
class TTKGAMEPLAYWORKTEST_API AArcingBullet : public ATTKGameplayWorkTestBullet
{
	GENERATED_BODY()

	FVector CurrentVelocity = FVector::ZeroVector;
	
protected:
	virtual void BeginPlay() override;

	virtual FVector GetNewLocation(float DeltaSeconds) override;
};
