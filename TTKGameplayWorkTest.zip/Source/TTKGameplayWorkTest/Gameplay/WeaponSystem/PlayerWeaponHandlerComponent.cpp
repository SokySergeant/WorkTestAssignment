﻿#include "PlayerWeaponHandlerComponent.h"
#include "Weapons/Gun.h"

UPlayerWeaponHandlerComponent::UPlayerWeaponHandlerComponent()
{
	PrimaryComponentTick.bCanEverTick = false;
}

void UPlayerWeaponHandlerComponent::BeginPlay()
{
	Super::BeginPlay();

	//Spawn weapons
	for(int i = 0; i < WeaponTemplates.Num(); i++)
	{
		Weapons.Add(GetWorld()->SpawnActor<AGun>(WeaponTemplates[i]));
		Weapons[i]->MyUser = GetOwner();
	}
}


void UPlayerWeaponHandlerComponent::SwitchWeaponUp()
{
	if(CurrentWeaponIndex < Weapons.Num() - 1)
	{
		CurrentWeaponIndex++;
	}else //Wrap around
	{
		CurrentWeaponIndex = 0;
	}
	
	OnWeaponSwitch.Broadcast(CurrentWeaponIndex);
}

void UPlayerWeaponHandlerComponent::SwitchWeaponDown()
{
	if(CurrentWeaponIndex > 0)
	{
		CurrentWeaponIndex--;
	}else //Wrap around
	{
		CurrentWeaponIndex = Weapons.Num() - 1;
	}
	
	OnWeaponSwitch.Broadcast(CurrentWeaponIndex);
}

void UPlayerWeaponHandlerComponent::TryShoot()
{
	Weapons[CurrentWeaponIndex]->Use();
}

void UPlayerWeaponHandlerComponent::TryReload()
{
	Weapons[CurrentWeaponIndex]->Reload();
}