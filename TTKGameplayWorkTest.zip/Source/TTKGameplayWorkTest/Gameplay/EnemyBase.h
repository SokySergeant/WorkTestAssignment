﻿#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "EnemyBase.generated.h"

class UTTKGameplayWorkTestEnemySystemComponent;
class UHealthComponent;

UCLASS()
class TTKGAMEPLAYWORKTEST_API AEnemyBase : public ACharacter
{
	GENERATED_BODY()

public:
	AEnemyBase();
	
	//Components
	UPROPERTY(VisibleAnywhere)
	UTTKGameplayWorkTestEnemySystemComponent* EnemySystemComponent;
	
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	UHealthComponent* HealthComponent;

	//Functions
	UFUNCTION()
	void Die();

protected:
	virtual void BeginPlay() override;
};
