﻿#include "HomingBullet.h"

#include "Kismet/GameplayStatics.h"
#include "Kismet/KismetMathLibrary.h"
#include "TTKGameplayWorkTest/Gameplay/TTKGameplayWorkTestEnemySystem.h"

void AHomingBullet::BeginPlay()
{
	Super::BeginPlay();

	//Get enemy system
	if (const UWorld* World = GetWorld())
	{
		if (const UGameInstance* GameInstance = World->GetGameInstance())
		{
			EnemySystem = GameInstance->GetSubsystem<UTTKGameplayWorkTestEnemySystem>();
		}
	}
}

FVector AHomingBullet::GetNewLocation(float DeltaSeconds)
{
	//Will move the bullet straight forward if returned
	FVector StraightAheadLocation = GetActorLocation() + GetActorForwardVector() * Speed * DeltaSeconds;
	
	//Find closest enemy
	float ClosestDistance = 100000.f;
	TObjectPtr<UTTKGameplayWorkTestEnemySystemComponent> ClosestEnemy = nullptr;
	for(int i = 0; i < EnemySystem->Enemies.Num(); i++)
	{
		float Distance = FVector::Distance(EnemySystem->Enemies[i]->GetComponentLocation(), GetActorLocation());
		if(Distance < ClosestDistance) //Found a closer enemy
		{
			ClosestDistance = Distance;
			ClosestEnemy = EnemySystem->Enemies[i];
		}
	}

	//Found no enemies
	if(!ClosestEnemy) return StraightAheadLocation;

	//Closest enemy is still too far away
	if(ClosestDistance > Range) return StraightAheadLocation;

	//Rotate to point towards closest enemy
	FRotator LookAtRotation = UKismetMathLibrary::FindLookAtRotation(GetActorLocation(), ClosestEnemy->GetComponentLocation());
	FRotator NewRotation = FMath::Lerp(GetActorRotation(), LookAtRotation, HomingPower);
	SetActorRotation(NewRotation);
	
	return StraightAheadLocation;
}

