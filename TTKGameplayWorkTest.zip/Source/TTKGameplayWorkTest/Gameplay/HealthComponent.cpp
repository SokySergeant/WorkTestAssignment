﻿#include "HealthComponent.h"

UHealthComponent::UHealthComponent()
{
	PrimaryComponentTick.bCanEverTick = false;
}

void UHealthComponent::BeginPlay()
{
	Super::BeginPlay();

	CurrentHealth = MaxHealth;
}

void UHealthComponent::UpdateHealthBy(int HpAmount)
{
	if(IsDead) return;
	
	//Update health, don't allow it to go below 0 or above MaxHealth
	int NewHealth = CurrentHealth + HpAmount;
	NewHealth = FMath::Clamp(NewHealth, 0, MaxHealth);
	CurrentHealth = NewHealth;

	//Die if ran out of health
	if(CurrentHealth == 0)
	{
		OnDeath.Broadcast();
		IsDead = true;
	}
}
