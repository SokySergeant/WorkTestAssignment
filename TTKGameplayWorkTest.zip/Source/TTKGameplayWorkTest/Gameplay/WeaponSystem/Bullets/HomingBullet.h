﻿#pragma once

#include "CoreMinimal.h"
#include "TTKGameplayWorkTestBullet.h"
#include "HomingBullet.generated.h"

class UTTKGameplayWorkTestEnemySystem;

UCLASS()
class TTKGAMEPLAYWORKTEST_API AHomingBullet : public ATTKGameplayWorkTestBullet
{
	GENERATED_BODY()
	
	UPROPERTY(EditAnywhere)
	float Speed = 500.f;

	UPROPERTY(EditAnywhere)
	float Range = 1000.f;

	UPROPERTY(EditAnywhere, meta = (UIMin = 0, UIMax = 1))
	float HomingPower = 0.1f;

protected:
	virtual void BeginPlay() override;

	virtual FVector GetNewLocation(float DeltaSeconds) override;

	UPROPERTY()
	TObjectPtr<UTTKGameplayWorkTestEnemySystem> EnemySystem;
};
