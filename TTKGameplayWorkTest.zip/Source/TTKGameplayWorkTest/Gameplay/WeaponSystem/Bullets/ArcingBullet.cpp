﻿#include "ArcingBullet.h"

void AArcingBullet::BeginPlay()
{
	Super::BeginPlay();
	
	SetActorRotation(GetActorRotation() + FRotator(40, 0, 0));
	CurrentVelocity = FVector::VectorPlaneProject(GetActorForwardVector(), FVector::UpVector) * 100;
	CurrentVelocity += GetActorForwardVector().ProjectOnToNormal(FVector::UpVector) * 50;
}

FVector AArcingBullet::GetNewLocation(float DeltaSeconds)
{
	FVector NewLocation = GetActorLocation();
	NewLocation += CurrentVelocity;
	CurrentVelocity.Z -= 0.982;
	
	return NewLocation;
}
