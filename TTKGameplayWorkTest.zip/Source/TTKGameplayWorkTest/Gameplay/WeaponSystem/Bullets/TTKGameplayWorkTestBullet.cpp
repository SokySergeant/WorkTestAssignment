
#include "TTKGameplayWorkTestBullet.h"
#include "Components/SphereComponent.h"
#include "TTKGameplayWorkTest/Gameplay/HealthComponent.h"
#include "TTKGameplayWorkTest/Gameplay/TTKGameplayWorkTestEnemySystem.h"

ATTKGameplayWorkTestBullet::ATTKGameplayWorkTestBullet(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	PrimaryActorTick.bStartWithTickEnabled = true;
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickGroup = TG_PostPhysics;
	
	CollisionComponent = CreateDefaultSubobject<USphereComponent>(TEXT("Collision"));
	CollisionComponent->SetSphereRadius(50);
	CollisionComponent->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	CollisionComponent->SetCollisionProfileName("NoCollision");
	
	RootComponent = CollisionComponent;
}

void ATTKGameplayWorkTestBullet::BeginPlay()
{
	Super::BeginPlay();
	
	if (const UWorld* World = GetWorld())
	{
		if (const UGameInstance* GameInstance = World->GetGameInstance())
		{
			if (auto* EnemySystem = GameInstance->GetSubsystem<UTTKGameplayWorkTestEnemySystem>())
			{
				EnemySystem->Bullets.Add(this);
			}
		}
	}
}

void ATTKGameplayWorkTestBullet::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);

	if (const UWorld* World = GetWorld())
	{
		if (const UGameInstance* GameInstance = World->GetGameInstance())
		{
			if (auto* EnemySystem = GameInstance->GetSubsystem<UTTKGameplayWorkTestEnemySystem>())
			{
				EnemySystem->Bullets.Remove(this);
			}
		}
	}
}

void ATTKGameplayWorkTestBullet::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);
	
	//Move
	SetActorLocation(GetNewLocation(DeltaSeconds));
}

void ATTKGameplayWorkTestBullet::HandleCollision(AActor* OtherActor)
{
	//Damage enemy
	if(UHealthComponent* HealthComponent = OtherActor->FindComponentByClass<UHealthComponent>())
	{
		HealthComponent->UpdateHealthBy(-Damage);
	}
	
	Destroy();
}

FVector ATTKGameplayWorkTestBullet::GetNewLocation(float DeltaSeconds)
{
	return GetActorLocation();
}
