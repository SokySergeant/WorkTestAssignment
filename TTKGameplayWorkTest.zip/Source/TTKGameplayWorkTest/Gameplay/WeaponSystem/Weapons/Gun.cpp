﻿#include "Gun.h"
#include "Kismet/KismetSystemLibrary.h"
#include "TTKGameplayWorkTest/Gameplay/WeaponSystem/Bullets/TTKGameplayWorkTestBullet.h"

void AGun::BeginPlay()
{
	Super::BeginPlay();

	CurrentAmmo = MaxAmmo;
	CurrentInMag = MagSize;
}

void AGun::Use()
{
	//Don't shoot if in cooldown
	if(GetWorld()->GetTimerManager().IsTimerActive(TimeBetweenShotsTimerHandle)) return;

	//Don't shoot if reloading
	if(GetWorld()->GetTimerManager().IsTimerActive(ReloadTimerHandle)) return;
	
	//Don't shoot if there are no bullets in mag, initiate reload instead
	if(CurrentInMag == 0)
	{
		Reload();
		return;
	}

	//Decrement bullet amount
	CurrentInMag--;

	//Spawn bullet
	FActorSpawnParameters SpawnInfo;
	SpawnInfo.Owner = MyUser;
	SpawnInfo.Instigator = MyUser->GetInstigator();
	SpawnInfo.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	SpawnInfo.bDeferConstruction = true;

	ATTKGameplayWorkTestBullet* Bullet = GetWorld()->SpawnActor<ATTKGameplayWorkTestBullet>(BulletTemplate, SpawnInfo);
	FQuat ShootDirection = MyUser->GetActorQuat();
	FVector ShootLocation = MyUser->GetActorLocation();
	ShootLocation += ShootDirection.GetForwardVector() * 300;
	Bullet->FinishSpawning(FTransform(ShootDirection.Rotator(), ShootLocation));

	UKismetSystemLibrary::DrawDebugArrow(this, ShootLocation, ShootLocation + (ShootDirection.GetForwardVector() * 500), 150, FLinearColor::Red, 0.5, 2);

	Bullet->SetLifeSpan(4);

	//Start cooldown
	GetWorld()->GetTimerManager().SetTimer(TimeBetweenShotsTimerHandle, this, &AGun::EndCooldown, TimeBetweenShots);
}

void AGun::EndUse() {}

void AGun::Reload()
{
	//Don't reload if already reloading
	if(GetWorld()->GetTimerManager().IsTimerActive(ReloadTimerHandle)) return;

	//Don't reload if mag is full
	if(CurrentInMag == MagSize) return;

	//Don't reload if out of ammo
	if(CurrentAmmo == 0) return;

	GetWorld()->GetTimerManager().SetTimer(ReloadTimerHandle, this, &AGun::FinishReload, ReloadTime);
}

void AGun::FinishReload()
{
	//Find amount of ammo to load
	int AmmoToLoad = FMath::Min(CurrentAmmo, MagSize - CurrentInMag);

	CurrentAmmo -= AmmoToLoad;
	CurrentInMag += AmmoToLoad;
}

float AGun::GetReloadTimePercent()
{
	float RemainingTime = GetWorld()->GetTimerManager().GetTimerRemaining(ReloadTimerHandle);

	if(RemainingTime == -1) return 0.f; //The timer is not currently active
	
	return ReloadTime - RemainingTime / ReloadTime;
}
