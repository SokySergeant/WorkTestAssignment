﻿#include "EnemyBase.h"
#include "HealthComponent.h"
#include "TTKGameplayWorkTestEnemySystem.h"

AEnemyBase::AEnemyBase()
{
	PrimaryActorTick.bCanEverTick = false;

	//Create enemy system component
	EnemySystemComponent = CreateDefaultSubobject<UTTKGameplayWorkTestEnemySystemComponent>(TEXT("EnemySystemComponent"));
	EnemySystemComponent->SetupAttachment(RootComponent);

	//Create health component
	HealthComponent = CreateDefaultSubobject<UHealthComponent>(TEXT("HealthComponent"));
}

void AEnemyBase::BeginPlay()
{
	Super::BeginPlay();

	//Bind delegates
	HealthComponent->OnDeath.AddDynamic(this, &AEnemyBase::Die);
}

void AEnemyBase::Die()
{
	Destroy();
}
