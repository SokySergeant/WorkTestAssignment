#pragma once

#include "CoreMinimal.h"
#include "UObject/Object.h"
#include "TTKGameplayWorkTestBullet.generated.h"

UCLASS()
class TTKGAMEPLAYWORKTEST_API ATTKGameplayWorkTestBullet : public AActor
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere)
	int Damage = 1;

public:
	ATTKGameplayWorkTestBullet(const FObjectInitializer& ObjectInitializer);
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	virtual void Tick(float DeltaSeconds) override;
	void HandleCollision(AActor* OtherActor);

	virtual FVector GetNewLocation(float DeltaSeconds);
	
protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Collision, meta = (AllowPrivateAccess = "true"))
	class USphereComponent* CollisionComponent;
};
