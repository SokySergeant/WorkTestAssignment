
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "TTKGameplayWorkTestGameMode.generated.h"

UCLASS(minimalapi)
class ATTKGameplayWorkTestGameMode : public AGameModeBase
{
	GENERATED_BODY()

public:
	ATTKGameplayWorkTestGameMode();
};



