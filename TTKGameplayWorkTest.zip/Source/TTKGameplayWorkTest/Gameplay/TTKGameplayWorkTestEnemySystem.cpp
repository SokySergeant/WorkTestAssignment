
#include "TTKGameplayWorkTestEnemySystem.h"
#include "Engine/GameInstance.h"
#include "Components/SphereComponent.h"
#include "WeaponSystem/Bullets/TTKGameplayWorkTestBullet.h"

//////////////////////////////////////////////////////////

void UTTKGameplayWorkTestEnemySystemComponent::BeginPlay()
{
	Super::BeginPlay();

	if (const UWorld* World = GetWorld())
	{
		if (const UGameInstance* GameInstance = World->GetGameInstance())
		{
			if (auto* EnemySystem = GameInstance->GetSubsystem<UTTKGameplayWorkTestEnemySystem>())
			{
				EnemySystem->Enemies.Add(this);
			}
		}
	}
}

void UTTKGameplayWorkTestEnemySystemComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);

	if (const UWorld* World = GetWorld())
	{
		if (const UGameInstance* GameInstance = World->GetGameInstance())
		{
			if (auto* EnemySystem = GameInstance->GetSubsystem<UTTKGameplayWorkTestEnemySystem>())
			{
				EnemySystem->Enemies.Remove(this);
			}
		}
	}
}

//////////////////////////////////////////////////////////


void UTTKGameplayWorkTestEnemySystem::Tick(float DeltaTime)
{
	for(int i = 0; i < Enemies.Num(); i++)
	{
		for(int ii = 0; ii < Bullets.Num(); ii++)
		{
			auto* CollisionComp = Bullets[ii]->FindComponentByClass<USphereComponent>();

			const float Dist = FVector::Distance(Bullets[ii]->GetActorLocation(), Enemies[i]->GetComponentLocation());
			if(Dist < CollisionComp->GetScaledSphereRadius() + 300)
			{
				Bullets[ii]->HandleCollision(Enemies[i]->GetOwner());
			}
		}
	}
}
