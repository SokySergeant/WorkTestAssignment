﻿#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "PlayerWeaponHandlerComponent.generated.h"

class AGun;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnWeaponSwitchDelegate, int, NewWeaponIndex);

UCLASS(ClassGroup=(Custom), meta=(BlueprintSpawnableComponent))
class TTKGAMEPLAYWORKTEST_API UPlayerWeaponHandlerComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	//Weapon variables
	UPROPERTY(EditAnywhere)
	TArray<TSubclassOf<AGun>> WeaponTemplates;
	
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	TArray<TObjectPtr<AGun>> Weapons;
	
	UPROPERTY(VisibleAnywhere)
	int CurrentWeaponIndex = 0;

	//Functions
	UPlayerWeaponHandlerComponent();

	void SwitchWeaponUp();
	void SwitchWeaponDown();
	void TryShoot();
	void TryReload();

	UFUNCTION(BlueprintCallable, BlueprintPure)
	AGun* GetCurrentWeapon() { return Weapons[CurrentWeaponIndex]; };

	//Delegates
	UPROPERTY(BlueprintAssignable)
	FOnWeaponSwitchDelegate OnWeaponSwitch; 

protected:
	virtual void BeginPlay() override;
};
