﻿#pragma once

#include "CoreMinimal.h"
#include "UObject/Object.h"
#include "Gun.generated.h"

class ATTKGameplayWorkTestBullet;

UCLASS()
class TTKGAMEPLAYWORKTEST_API AGun : public AActor
{
	GENERATED_BODY()

public:
	//Ammo variables
	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	int MaxAmmo = 20;
	
	UPROPERTY(BlueprintReadOnly, VisibleAnywhere)
	int CurrentAmmo;
	
	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	int MagSize = 5;
	
	UPROPERTY(BlueprintReadOnly, VisibleAnywhere)
	int CurrentInMag;

	//Cooldown variables	
	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	float TimeBetweenShots = 0.2f;
	
	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	float ReloadTime = 1.f;

private:
	FTimerHandle TimeBetweenShotsTimerHandle;
	void EndCooldown() {};
	FTimerHandle ReloadTimerHandle;
	void FinishReload();

public:
	//Bullet
	UPROPERTY(EditAnywhere)
	TSubclassOf<ATTKGameplayWorkTestBullet> BulletTemplate;

	//Functions
	virtual void BeginPlay() override;
	
	virtual void Use();
	virtual void EndUse();

	void Reload();

	UPROPERTY(VisibleAnywhere)
	TObjectPtr<AActor> MyUser;

	UFUNCTION(BlueprintCallable, BlueprintPure)
	float GetReloadTimePercent();
};
