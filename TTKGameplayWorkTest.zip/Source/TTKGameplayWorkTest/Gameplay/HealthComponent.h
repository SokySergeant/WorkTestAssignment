﻿#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "HealthComponent.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnDeathDelegate);

UCLASS(ClassGroup=(Custom), meta=(BlueprintSpawnableComponent))
class TTKGAMEPLAYWORKTEST_API UHealthComponent : public UActorComponent
{
	GENERATED_BODY()

	//Health variables
	UPROPERTY(EditAnywhere)
	int MaxHealth = 10;
	
	UPROPERTY(VisibleAnywhere)
	int CurrentHealth;

public:
	UHealthComponent();
	
	//Death variables
	UPROPERTY(BlueprintAssignable)
	FOnDeathDelegate OnDeath;

	UPROPERTY(VisibleAnywhere)
	bool IsDead = false;
	
	//Functions
	UFUNCTION(BlueprintCallable)
	void UpdateHealthBy(int HpAmount);
	
	UFUNCTION(BlueprintCallable, BlueprintPure)
	float GetHealthPercentage() { return static_cast<float>(CurrentHealth) / static_cast<float>(MaxHealth); };

protected:
	virtual void BeginPlay() override;
};
